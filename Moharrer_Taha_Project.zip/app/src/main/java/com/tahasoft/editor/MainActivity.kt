package com.tahasoft.editor

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.util.*
import kotlin.concurrent.schedule

class MainActivity : AppCompatActivity() {
    lateinit var editText: EditText
    lateinit var tvSignature: TextView
    val prefsName = "taha_prefs"
    val lastFileName = "last_doc.txt"
    var autosaveTimer: Timer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        editText = findViewById(R.id.edit_text)
        tvSignature = findViewById(R.id.tv_signature)
        val btnSave: Button = findViewById(R.id.btn_save)
        val btnExport: Button = findViewById(R.id.btn_export)
        val btnWhatsapp: Button = findViewById(R.id.btn_whatsapp)

        // load last
        loadLastDocument()

        // autosave on text changed (simple)
        editText.addTextChangedListener(object: android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                autosaveTimer?.cancel()
                autosaveTimer = Timer()
                autosaveTimer?.schedule(1500) { runOnUiThread { saveDocument(lastFileName, editText.text.toString()) } }
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })

        btnSave.setOnClickListener { saveDocument(lastFileName, editText.text.toString()); Toast.makeText(this, "تم الحفظ", Toast.LENGTH_SHORT).show() }
        btnExport.setOnClickListener { exportPdfWithWatermark(editText.text.toString()) }
        btnWhatsapp.setOnClickListener { shareToWhatsApp() }
    }

    private fun saveDocument(fileName: String, content: String) {
        try {
            openFileOutput(fileName, Context.MODE_PRIVATE).use { fos -> fos.write(content.toByteArray(Charsets.UTF_8)) }
            val prefs = getSharedPreferences(prefsName, Context.MODE_PRIVATE)
            val recent = prefs.getString("recent_list", "") ?: ""
            val updated = (fileName + "," + recent.split(",").filter { it.isNotEmpty() && it != fileName }.joinToString(","))
            prefs.edit().putString("recent_list", updated).apply()
        } catch (e: Exception) { e.printStackTrace() }
    }

    private fun loadLastDocument() {
        try {
            val f = File(filesDir, lastFileName)
            if (f.exists()) { editText.setText(f.readText(Charsets.UTF_8)) }
        } catch (e: Exception) { e.printStackTrace() }
    }

    private fun exportPdfWithWatermark(content: String) {
        try {
            val outFile = File(getExternalFilesDir(null), "exported_${System.currentTimeMillis()}.pdf")
            val pageWidth = 595
            val pageHeight = 842
            val pdf = PdfDocument()
            val paint = Paint()
            paint.textSize = 12f

            val watermarkPaint = Paint()
            watermarkPaint.textSize = 10f
            watermarkPaint.alpha = 140

            val lines = content.split("\n")
            var idx = 0
            val linesPerPage = 40
            var pageNo = 0
            while (idx < lines.size) {
                pageNo++
                val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNo).create()
                val page = pdf.startPage(pageInfo)
                val canvas = page.canvas
                var y = 40f
                for (i in 0 until linesPerPage) {
                    if (idx >= lines.size) break
                    canvas.drawText(lines[idx], 20f, y, paint)
                    y += 18f
                    idx++
                }
                val footer = getString(R.string.taha_signature)
                canvas.drawText(footer, 20f, (pageHeight - 20).toFloat(), watermarkPaint)
                pdf.finishPage(page)
            }
            outFile.outputStream().use { pdf.writeTo(it) }
            pdf.close()
            Toast.makeText(this, "تم إنشاء PDF: ${outFile.name}", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { e.printStackTrace(); Toast.makeText(this, "خطأ أثناء التصدير", Toast.LENGTH_SHORT).show() }
    }

    private fun shareToWhatsApp() {
        try {
            val dir = getExternalFilesDir(null)
            val files = dir?.listFiles()?.filter { it.name.endsWith(".pdf") }?.sortedByDescending { it.lastModified() }
            if (files == null || files.isEmpty()) { Toast.makeText(this, "لا يوجد ملف للتشارك", Toast.LENGTH_SHORT).show(); return }
            val file = files[0]
            val uri = FileProvider.getUriForFile(this, "com.tahasoft.editor.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND)
            intent.type = "application/pdf"
            intent.putExtra(Intent.EXTRA_STREAM, uri)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            intent.setPackage("com.whatsapp")
            startActivity(intent)
        } catch (e: ActivityNotFoundException) { Toast.makeText(this, "WhatsApp غير مثبت", Toast.LENGTH_SHORT).show() }
          catch (e: Exception) { e.printStackTrace(); Toast.makeText(this, "فشل المشاركة", Toast.LENGTH_SHORT).show() }
    }
}
