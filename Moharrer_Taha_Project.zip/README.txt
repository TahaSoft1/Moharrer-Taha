مشروع Android جاهز للبناء - Moharrer Taha
-------------------------------------
ما في هذا الحزمة:
- مشروع Android (Kotlin) مع شاشات: Splash, Main Editor
- حفظ تلقائي، استرجاع آخر مستند، تصدير PDF مع watermark، مشاركة PDF إلى واتساب.
- RTL مفعّل، ملف signature نصي يظهر أسفل واجهة التطبيق.
- ضع أيقونات التطبيق (ic_launcher.png) داخل app/src/main/res/mipmap-*/
- ضع خط عربي في app/src/main/assets/fonts/arabic_font.ttf

كيفية البناء:
1) افتح المشروع في Android Studio (File > Open) وافتح مجلد /mnt/data/Moharrer_Taha_Project.
2) مزوّد Android SDK و JDK مثبتان. قم بمزامنة Gradle.
3) قم بإضافة أيقونة التطبيق في res/mipmap-* أو استبدل الموارد الموجودة.
4) قم بإعداد keystore لتوقيع الإصدار النهائي: Build > Generate Signed Bundle/APK.
5) أو لتجربة سريعة: Build > Build Bundle(s) / APK(s) > Build APK(s) ثم ثبت الـ APK الناتج على جهازك.

ملاحظات أمان/قانونية:
- التوقيع: لتستبدل إصدار موجود على متجر Play يجب أن تستخدم نفس keystore الأصلي.
- الرقم في التوقيع/الـ footer: 777676108
